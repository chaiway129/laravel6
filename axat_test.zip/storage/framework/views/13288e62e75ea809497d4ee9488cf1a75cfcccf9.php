<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Edit Employee</h2>
            </div>
            
        </div>
    </div>
   
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Warning!</strong> Please check input field code<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
  
    <form action="<?php echo e(route('employee.update',$employee->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
   
         <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Employee Name:</strong>
                    <input type="text" name="emp_name" value="<?php echo e($employee->emp_name); ?>" class="form-control" placeholder="Title">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                              <strong>Employee Status:</strong>
                <div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="emp_status" id="flexRadioDefault1" value="active" <?php if($employee->emp_status=='active'){ echo 'checked'; }else{ echo '';} ?>>
  <label class="form-check-label" for="flexRadioDefault1">
    Active
  </label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="emp_status" id="flexRadioDefault2" value="inactive" <?php  if($employee->emp_status=='inactive'){ echo 'checked'; }else{ echo '';} ?>>
  <label class="form-check-label" for="flexRadioDefault2">
    Inactive
  </label>
</div>
    
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
              <button type="submit" class="btn btn-primary">Submit</button>
               <a class="btn btn-primary" href="<?php echo e(route('employee.index')); ?>"> Back</a>
            </div>
        </div>
   
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\axat_test\resources\views/employee/edit.blade.php ENDPATH**/ ?>